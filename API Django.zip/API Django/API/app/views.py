from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.http import JsonResponse
from app.serilizer import seri
from app.models import Mybio
# Create your views here.
@api_view(['GET'])
def resthome(request):
    task = Mybio.objects.all()
    ser = seri(task,many=True)

    return Response(ser.data)