from dataclasses import fields
from msilib.schema import Class
from pyexpat import model
from rest_framework import serializers
from app.models import Mybio


class seri(serializers.ModelSerializer):
    class Meta:
        model = Mybio
        fields ='__all__'