from operator import mod
from django.db import models

# Create your models here.
class Mybio(models.Model):
    author = models.CharField(max_length=100)
    title = models.CharField(max_length=100)
    published_date = models.DateTimeField(auto_now_add=True)
    image_url = models.ImageField(null=True, upload_to="static/img/")

    def __str__(self):
        return self.title
    
    